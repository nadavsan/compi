let tc_tests : cg_test list = [
  {test = "((lambda (x) (eq? x 3)) 3)"; expected = "#t"};
]
